Task Reminder Application for Android
=========

It's a Task reminder android application with many features like reminder about tasks etc.


> Actually it's very unique and special for me bacuse it's my first Android application and i used many new things with it like:

  - Twitter Bootstrap Elements like EditText and Button etc.
  - Minimal duplicacy like same code for Add/Update task
  - and many more....

I have full code for this app along with Twitter Bootsrap module in this repo. All you have to do is check it out. 

Version
----

1.0.0

Tech
-----------

This App uses a number of Tools to work properly:

* [IntelliJ Idea](http://www.jetbrains.com/idea/download/) - Best Java IDE for Java beased techs
* [ANdroid SDK](https://developer.android.com/sdk/index.html?hl=i) - Android SDK
* [Twitter Bootstrap](http://getbootstrap.com/) - For Android Element like EditText and Button etc
* [Java](https://java.com/en/download/index.jsp) - Java SE 1.7
* [Git](http://git-scm.com/) - Best S/W versioning tool 

Installation
--------------
* [Task Reminder APK](https://github.com/hitenpratap/Task-Reminder-App/blob/master/TaskReminderApp.apk?raw=true) - Just download it from here and enjoy.

```
Just download the app from repo and install it on your android device.
```

**Open Source Software, Hell Yeah!**
